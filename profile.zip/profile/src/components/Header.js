import React, {Component} from 'react';
import { StyleSheet, Text, View,AppRegistry } from 'react-native';

  const Header = (props) =>{
        return(
            <View style={styles.viewStyle}>
              <Text style={styles.textStyle}>{props.headerText}</Text>
            </View>
        );
  };

const styles = StyleSheet.create({
  viewStyle: {
    backgroundColor:'#f4f4f8',
    justifyContent:'center',
    alignItems:'center',
    marginTop:15
  },
  textStyle:{
    fontSize:30
  }
});
export default Header;
